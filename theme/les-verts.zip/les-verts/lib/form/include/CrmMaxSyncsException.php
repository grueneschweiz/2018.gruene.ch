<?php

namespace SUPT;

use Exception;

/**
 * Exception thrown when CRM syncs per run exceed the allowed maximum.
 */
class CrmMaxSyncsException extends Exception {
}
